package com.example.myapplication3.Recommend;

import android.widget.Button;

public interface OnButttonClick {
    void onClick(String brname, Button btn);
}
