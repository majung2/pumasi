package com.example.myapplication3.Shopping;
import java.util.Map;

public class Brand {

    public String name;
    public String id;
    public boolean bought;
    public String category;
    public Number rating;

    // Firestore에 연동하려면 빈 생성자가 필수이다.
    Brand() {}

}